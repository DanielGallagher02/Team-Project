<?php

    // include the header
    include('header.php')

?>

<div id="bar">
    
<h1>Welcome to our Pool Bar</h1>
<img src="images/bar.jpg">

</div>

<?php

    // include the header
    include('footer.php')

?>