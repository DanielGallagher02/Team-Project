<div class="footer-content">
  <!-- footer 
  footer will contain login for staff
  buttons for other pages
  copyright information
  connection to the social media -->
  <footer>
    <h3>Welcome to iHOTEL</h3>
    <ul class="socials">
      <li><a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li>
      <li><a href="#"><i class="fa fa-twitter"></i></a></li>
      <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
      <li><a href="#"><i class="fa fa-youtube"></i></a></li>
      <li><a href="#"><i class="fa fa-linkedin-square"></i></a></li>
    </ul>
    <div class="footer-menu">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="customerLogin.php">Login</a></li>
        <li><a href="bookNow.php">Book Now</a></li>
        <li><a href="staffLogin.php" >Staff Login</a></li>
      </ul>
     
    

      
      </div>
      <div class="footer-bottom">

        <p>copyright &copy;2023 <a href="#">BestTeamEver</a></p>
      </div>
    
  </footer>
</div>
</body>