<?php

    // include the header
    include('header.php');

?>

<div id="new_page">
    
    <h1>This is a new template page!</h1>
    <h1>Please copy it and edit it for new pages.</h1>

</div>

<?php

    // include the header
    include('footer.php');

?>